export class Hero {
    id: Number;
    username: String;
    paswd: String;
    status: Number;

    constructor() {

    }
}