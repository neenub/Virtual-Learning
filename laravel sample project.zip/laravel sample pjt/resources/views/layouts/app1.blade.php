<htmll>
    <body>
        <div>
            <a href="/index">Home</a>
            <a href="/about">About</a>
            <a href="/service">Services</a>
            @yield('content')
        </div>
    </body>
</htmll>