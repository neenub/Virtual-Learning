@extends('layouts.app1')
@section('content')
<h1>ABOUT</h1>
<p>I am Neethu C Joseph</p>
@endsection